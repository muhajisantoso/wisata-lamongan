<?php

return [
    'pinjam' => [
        'success' => 'Pengajuan pinjam alat berhasil, harap menunggu untuk di konfirmasi',
        'draft' => 'Pengajuam pinjam alat berhasil disimpan',
        'hapus' => 'Pengajuan pinjam alat berhasil dihapus',
        'fail' => 'Pengajuan pinjam alat gagal, :keterangan'
    ]
];
